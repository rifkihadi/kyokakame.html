# scriptNembakBetina
gua ngebuat script beginian lantaran gabut dan juga sekalian mo nembak gebetan gitu, lah tahu dah 
diterima apa nggak urusan nanti , yang penting yakin owkwowkwkwkww 


